<?php
namespace Webtechnologies\Config;
class Dev {
    public function __construct()
    {
        die('Dev config');
    }
}
?>