<?php
class UserController {
    public function __construct() {
        die('User controller');
    }
}
?>