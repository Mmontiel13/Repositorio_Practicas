<?php

    require_once __DIR__ . '/app/start.php';
    //Probando acceso a las distintas clases
    //$user = new User();
    //$user = new UserController();
    //$user = new UserTemplate();

    //$account = new Account();
    //$account = new AccountController();
    $account = new AccountTemplate();

?>